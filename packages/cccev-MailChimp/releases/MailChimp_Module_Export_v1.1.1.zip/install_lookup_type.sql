INSERT INTO [core_lookup_type]
           ([guid]
           ,[lookup_type_name]
           ,[lookup_type_desc]
           ,[lookup_category]
           ,[qualifier_1_title]
           ,[qualifier_2_title]
           ,[organization_id]
           ,[system_flag]
           ,[qualifier_3_title]
           ,[qualifier_4_title]
           ,[qualifier_5_title]
           ,[qualifier_6_title]
           ,[qualifier_7_title]
           ,[qualifier_8_title])
     VALUES (
           'd5aa90da-2de6-4e66-a966-db6133ed18ec'
           ,'Cccev MailChimp Lists'
           ,'Used for integration with MailChimp'
           ,''
           ,'ListID'
           ,'NewsletterID'
           ,1
           ,0
           ,'Last Sync'
           ,''
           ,''
           ,''
           ,''
           ,'ImageURL')
GO
